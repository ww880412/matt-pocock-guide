# Grilling: design tree and frontier rounds

Build a shared understanding of the requested scope as a **design tree**: decisions branch into the decisions that depend on them. Record each unresolved decision, its prerequisites, and any confirmed answer. Use the task, authoritative spec and actual user replies as evidence. Explicitly approved decisions and the instruction to proceed are already confirmed shared understanding; do not reopen them or invent new policy choices.

## Work the frontier in rounds

The **frontier** contains decisions whose prerequisites are settled. A question depending on an unanswered question belongs to a later round. Plan the current frontier, then deliver it **one decision per native question**, waiting for the actual reply before presenting the next question. A round is a planning unit, not permission to combine questions into one selector or show a textual multi-question form.

For example, if B depends on A and C is independent, the initial frontier is A and C. Ask A as one decision, record its actual answer, and ask C separately. B becomes eligible once A is settled. If C remains unanswered, C remains pending; do not substitute its recommendation, assume a complete round, or block independently authorized work whose prerequisites are satisfied. Recompute dependencies after each answer or new fact; never ask a stale question whose premise has changed. Complete the current round's unresolved frontier before starting a dependent round unless the user's steering changes the order.

Finding **facts** is the agent's job. Inspect the repository, filesystem, available tools and relevant sources yourself. Use a teammate only when delegation is available and permitted. An exploration still running is an unsettled prerequisite; only the decisions downstream of that exploration wait. Ask the user only for information they own or a genuine unresolved trade-off affecting scope, cost, compatibility or experience.

Start every new sub-agent with a fresh context window; do not fork the parent conversation. Give it a bounded task brief with explicit spec and evidence pointers, file scope, and expected output. On Codex, use `spawn_agent` with `fork_turns="none"` only when the current tool schema supports it. On other hosts, use their supported fresh-context controls; do not copy Codex parameters to Claude or Devin. If fresh-context delegation is unavailable, follow this skill's existing delegation limits or sequential fallback and disclose the limitation; do not claim an isolated agent ran. For factual exploration, identify the unresolved fact and downstream decisions; the agent returns evidence, not user answers or authorization.

## Ask and record actual decisions

Use `matt_pocock_ask` within an active workflow. For an independent capability, supply that selected public capability's id; keep the saved workflow unchanged. Follow the host's input-purpose and presentation restrictions, including the supplied card protocol. Do not start or transition a workflow merely to ask an independent capability's question.

Word each question so "yes" accepts your recommended answer; agreement must not require answering "no". This is a wording rule only: it does not bypass native answer collection or the tentative-selection and confirmation steps, and does not turn other replies or empty input into approval. Interpret the actual response through the existing card protocol.

Each question carries one concrete decision. Offer concise alternatives with one consistent recommendation and its trade-off, and allow custom input. A recommendation is advice, never an answer. Record a decision only after a valid actual response is collected. Timeout, empty input, unavailable UI, cancellation and interruption leave required decisions unresolved; none adopts a recommendation or grants authorization. Preserve existing pending cards and do not silently change their mode or replace them with conversation. If the current host cannot present a required decision, explain the specific limitation and follow the existing host policy for obtaining that decision; do not manufacture a receipt.

Only genuinely non-blocking clarifications may be optional under the existing question protocol. An optional unanswered question may be closed through that protocol; the chosen existing authorized default or ordinary implementation judgment must be attributed to that basis, not to a user answer. Never reclassify an existing required question as optional.

## Completion and continuation

The design discussion is complete when every relevant branch has been visited, no required decision is silently assumed, and shared understanding is confirmed. Existing explicit approval of the relevant scope or authoritative spec already satisfies that confirmation. If a material user-owned decision remains unresolved, the dependent work waits for the user's answer. Once decisions and confirmed scope are recorded, proceed directly with the next applicable authorized work; do not ask whether to continue or repeat permission for a step already authorized. External writes and destructive operations retain their existing authorization boundary.
