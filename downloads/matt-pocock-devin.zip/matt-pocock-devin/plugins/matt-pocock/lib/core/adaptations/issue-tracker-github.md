## 本地采纳补充 · 2026-10-08

以下约束优先于正文中不一致的默认步骤；已有用户授权与项目约定继续有效。

使用前核对目标 owner/repo、实际 gh 版本与 help。读取和外部写入分开；加载模板不授权创建 issue、标签、关系或评论。多行正文写文件后使用 --body-file，禁止将不可信正文拼进 shell。缺少写入授权时生成本地稿。

父子关系与阻塞关系是两件事。当前 help 支持时可用下方 native flags；否则将已创建子票加入已有来源 issue，使用 `gh api --method POST repos/<owner>/<repo>/issues/<parent-number>/sub_issues -F sub_issue_id=<child-database-id>`；先查询真实数字数据库 id，不能用 GraphQL node id 或猜测编号。平台不支持时记录明确 fallback，不默默丢关系。读取标签用 `gh label list --json name --limit <足够覆盖的数量>`；确认不存在后，在授权范围内 `gh label create <name> --description <description> --color <hex>`，不加 --force 覆盖现有标签。

# Issue tracker: GitHub

Issues and PRDs for this repo live as GitHub issues. Use the `gh` CLI for all operations.

## Conventions

- **Create an issue**: `gh issue create --title "..." --body "..."`. Use a heredoc for multi-line bodies.
- **Read an issue**: `gh issue view <number> --json number,title,body,labels,comments,state,url` for structured data; use `--comments` for a human-readable view.
- **List issues**: `gh issue list --state open --json number,title,body,labels,comments --jq '[.[] | {number, title, body, labels: [.labels[].name], comments: [.comments[].body]}]'` with appropriate `--label` and `--state` filters.
- **Make an issue a sub-issue of a parent**: `gh issue create --parent <parent> ...`, or `gh issue edit <parent> --add-sub-issue <child>` afterwards (`gh` 2.94+; verify the installed help supports these flags). Older CLI versions use the sub-issues API above with the child's actual database id. Where sub-issues are unavailable, use a parent task list plus `Part of #<parent>` in the child body.
- **Blocking**: GitHub's **native issue dependencies** are canonical. Use `gh issue create --blocked-by <n>,<n> ...` or `gh issue edit <child> --add-blocked-by <blocker>` (`gh` 2.94+; verify the installed help). Older CLI versions use `gh api --method POST repos/<owner>/<repo>/issues/<child>/dependencies/blocked_by -F issue_id=<blocker-db-id>`. Obtain the numeric **database id** with `gh api repos/<owner>/<repo>/issues/<n> --jq .id`; never substitute an issue number or GraphQL node id. If the platform lacks dependencies, record a `Blocked by: #<n>, #<n>` line in the child body. A ticket is unblocked only when every blocker is closed.
- **Count open blockers**: `gh api repos/<owner>/<repo>/issues/<n> --jq .issue_dependencies_summary.blocked_by` counts open blockers. With a supported `blockedBy` JSON field, `gh issue view <n> --json blockedBy --jq '[.blockedBy.nodes[] | select(.state == "OPEN")] | length'` filters out closed blockers. Do not use the total list length as the gate; a missing field or failed query is unknown, not zero. Use the REST count when the CLI field is unavailable or the returned nodes are incomplete.
- **Comment on an issue**: `gh issue comment <number> --body "..."`
- **Apply / remove labels**: `gh issue edit <number> --add-label "..."` / `--remove-label "..."`
- **Close**: post the explanation with `gh issue comment <number> --body "..."`, then `gh issue close <number>` only after the comment succeeds. On an already-closed issue, `gh issue close --comment` can drop the comment while still exiting 0; keep comment and close separate.

Use `git remote -v` to identify the user's intended project, then before the first write of a session check `gh repo view --json nameWithOwner,url`. In a fork, `gh` may default to the upstream parent. Match the result to the already-confirmed target; if it differs or no target was confirmed, resolve that with the user before writing. Pin subsequent commands to the confirmed target with `--repo <[host/]owner/repo>` (and explicit owner/repo paths for `gh api`), rather than changing persistent CLI defaults. Never file into `mattpocock/skills` merely because it distributes these skills; it is a valid target only if the user owns it and explicitly selected it. These checks do not themselves grant write permission.

## Pull requests as a triage surface

**PRs as a request surface: no.** _(Set to `yes` if this repo treats external PRs as feature requests; [triage](triage.md) reads this flag.)_

When set to `yes`, PRs run through the same labels and states as issues, using the `gh pr` equivalents:

- **Read a PR**: `gh pr view <number>`, then `gh pr view <number> --comments` (off a TTY, `--comments` prints comments without the body), and `gh pr diff <number>` for the diff.
- **List external PRs for triage**: `gh api --paginate 'repos/{owner}/{repo}/pulls?state=open&per_page=100'` then keep only REST `author_association` of `CONTRIBUTOR`, `FIRST_TIME_CONTRIBUTOR`, or `NONE` (drop `OWNER`/`MEMBER`/`COLLABORATOR`).
- **Comment / label / close**: `gh pr comment`, `gh pr edit --add-label`/`--remove-label`, `gh pr close`.

GitHub shares one number space across issues and PRs, so a bare `#42` may be either — resolve with `gh pr view 42` and fall back to `gh issue view 42`.

## When a skill says "publish to the issue tracker"

Create a GitHub issue.

## When a skill says "fetch the relevant ticket"

Run `gh issue view <number> --comments`.

## Wayfinding operations

Used by [wayfinder](wayfinder.md). The **map** is a single issue with **child** issues as tickets.

- **Map**: a single issue labelled `wayfinder:map`, holding the Notes / Decisions-so-far / Fog body. `gh issue create --label wayfinder:map`.
- **Child ticket**: an issue linked to the map as a GitHub sub-issue (see **Make an issue a sub-issue of a parent** above). Where sub-issues aren't enabled, add the child to a task list in the map body and put `Part of #<map>` at the top of the child body. Labels: `wayfinder:<type>` (`research`/`prototype`/`grilling`/`task`). Once claimed, the ticket is assigned to the driving dev.
- **Blocking**: use **Blocking** under Conventions.
- **Frontier query**: list the map's open children (`gh issue list --state open`, scoped to the map's sub-issues / task list), drop any with an open blocker (see **Count open blockers**, or resolve the issues in the fallback `Blocked by` line) or an assignee; first in map order wins. Unknown blocker state is not startable.
- **Claim**: `gh issue edit <n> --add-assignee @me` — the session's first write.
- **Resolve**: `gh issue comment <n> --body "<answer>"`, then `gh issue close <n>`, then append a context pointer (gist + link) to the map's Decisions-so-far.
