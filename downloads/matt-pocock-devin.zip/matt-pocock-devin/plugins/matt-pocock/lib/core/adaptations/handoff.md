## 本地采纳补充 · 2026-10-08

以下约束优先于正文中不一致的默认步骤；已有用户授权与项目约定继续有效。

用户明确指定交接文件路径时优先遵守；否则解析当前 OS 临时目录（macOS/Linux 使用 TMPDIR，缺失则 /tmp；Windows 使用 TEMP）。写入后检查文件真实存在且可读，再返回绝对路径；不只给拟议文件名。只写交接稿，不创建/启动后台会话，继续遵守引用已有产物和脱敏要求。

Write a portable handoff document summarising the current conversation. This skill only writes the document: it does not create, fork, or seed a session. Use the user's explicit output path, otherwise the OS temporary directory. The user or a receiving agent may use the document in a later session.

When an earlier deferral or superseded decision affects the next session, identify the decision, why it was made, its dated or revision-specific evidence, and what would warrant reopening it. Point to the existing decision record; if a later decision replaced it, link both in order. Distinguish historical observations from current facts. If the reason or reopening condition is unknown, say so. Omit this material when there is no relevant decision to carry forward.

Source: [chief-of-staff · Wiki](https://github.com/mattpocock/skills/blob/4ae2317ddb22b046e26455e4f9c9b3aaaf62212d/skills/in-progress/chief-of-staff/SKILL.md#wiki). Recording reopening conditions is a local addition.

Include a "suggested skills" section in the document, which suggests skills that the agent should invoke.

Do not duplicate content already captured in other artifacts (specs, plans, ADRs, issues, commits, diffs). Reference them by path or URL instead.

Redact any sensitive information, such as API keys, passwords, or personally identifiable information.

If the user passed arguments, treat them as a description of what the next session will focus on and tailor the doc accordingly.

## CRITICAL: Reference, don't duplicate — and redact

Do not copy content already captured in specs, plans, ADRs, issues, commits, or diffs — reference them by path or URL instead. Redact API keys, passwords, and personally identifiable information. Use the explicit output path, otherwise the OS temporary directory.
