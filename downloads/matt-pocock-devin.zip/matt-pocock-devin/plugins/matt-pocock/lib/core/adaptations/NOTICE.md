# Local adaptations

Approved SN-01/SN-02; see docs/product/V2-02-SAME-NAME-SPEC.md in the source project.

Matt repository: https://github.com/mattpocock/skills
Matt commit: 3cca18b368ae95cdbdebbff572ccafa662551015
LOGIC.md derives from skills/engineering/prototype/LOGIC.md, SHA-256 f61c7d249e786a79ef289018901c348271e1798dd0b0bc5607b5c6f4d4a01ab9.
wait-what.md incorporates the CONTEXT-MAP lookup idea from skills/productivity/wait-what/SKILL.md.
prototype.md derives from the frozen Pi procedure with only the approved logic branch and host constraints adapted.
Original frozen resources and manifests are unchanged. These files are local adaptations, not byte-identical upstream copies.
MIT licenses and copyright notices: packaged lib/resources/LICENSE (Pi) and lib/resources/matt/LICENSE (Matt).

## 2026-09-25 selected update

See docs/product/UPSTREAM-20260925.md in the source project. implement.md, code-review.md and writing-for-agents.md derive from Pi commit 157c21f75481f575f3c3575dc18e6f8ee271c756, packages/matt-pocock/procedures/. Local changes adapt review dispatch to available host tools, preserve review-only scope and missing-spec UNVERIFIED, and keep commits/publication behind existing authority. Frozen Pi resource hashes remain unchanged; these adapted files do not claim to be the original baseline.

## 2026-10-02 selected update

Matt inspected commit: d81f3a183412e71a5b1e84ca21bc1a35eea03a60 (https://github.com/mattpocock/skills).
The CONTEXT/GLOSSARY naming change is adapted as the shared local resource `local/domain-docs.md`, hash-pinned in `core/local-manifest.json` and required by domain-document consumers in the catalog. It resolves existing project conventions, both maps, ambiguous coexistence and missing sources without renaming user files or creating duplicate glossaries. `wait-what.md` uses that policy. Frozen Pi originals, domain template identity and teaching templates remain unchanged.

The three `pr` resources are copied unmodified from `skills/engineering/pr/` at the inspected commit; their former `skills/in-progress/pr/` paths are retired. Per-file commit, size and SHA-256 are in `core/matt-manifest.json`. PR content preserves its in-file author credit and sibling `CREDITS.md` (Dex Horthy / Humanlayer show-me); its agent metadata is retained. The catalog and local route guidance expose the same existing independent capability as stable. Ask-matt's original source remains pinned to its earlier commit: this is selected local navigation, not a claim of full upstream synchronization. `retro` and `implement-spec` are not introduced; `resolving-merge-conflicts` remains available. SDK and host mechanisms are outside this adaptation.

2026-10-02 complete upstream update: `implement-spec.md` and `retro.md` adapt Matt `d81f3a183412e71a5b1e84ca21bc1a35eea03a60` resources. The manifest binds each adapted procedure to the exact bundled upstream SHA256. The whole-spec protocol adds graph validation, exclusive ownership, dirty-work preservation, serial current-tip integration, failure/pause/resume records, local-tracker delivery, authorization and candidate-bound review. Retro preserves evidence categories while making environment edits a separately authorized task. These constraints are delivered as procedure bodies in both independent and workflow calls, not only as independent guidance. No scheduler or persistent SDK schema was added.

## 2026-10-08 selected two-batch update

User-approved scope: docs/product/UPSTREAM-20261008-IMPLEMENTATION.md, based on docs/reviews/UPSTREAM-FOLLOWUP-20261008.md. Matt source commit b0618bc436ad893b3c5e84e55fba86586d34a404; Pi source commit 1b4d1264630e51f0b192213f8ccd32d270ee5681 (packages/matt-pocock/procedures). Both sources retain their MIT notices in the package.

- ask-matt upstream SKILL.md is copied unchanged; its exact source commit/hash is in core/matt-manifest.json. Consultation reachability and host guidance are local adaptations, not upstream runtime code.
- implement, tdd, diagnosing-bugs: selected Matt ticket/seam/red evidence and Pi public-contract guidance, retaining existing BDD execution and local authority.
- code-review and local/deslop: selected Pi reachable-causality/per-predicate/evidence/verdict constraints, plus Matt standards-source discovery; local bounded review dispatch is retained.
- domain-modeling, codebase-design, prototype, improve-codebase-architecture, to-questionnaire: selected Pi fact/proposal/policy/readonly constraints; existing domain-docs and prototype branches retained.
- setup-matt-pocock-skills, issue-tracker-github, issue-tracker-gitlab, to-tickets, wayfinder: selected Matt identity/labels/relations and CLI corrections. Current official CLI/API references are recorded in the implementation evidence. Existing AFK continuation and authorization boundaries are retained.
- teach/handoff: selected Matt workspace/template paths, answer positions and OS temp handling; selected Pi read-only teaching and real output existence. Explicit user paths and prior answers win.
- local/wizard-template.sh derives from Matt skills/engineering/wizard/template.sh at the commit above. Local deltas reject all input EOF and env symlinks, and fix literal-quote readback on Bash 3.2. The original frozen template remains unchanged. The local asset is hash-pinned by core/local-manifest.json and delivered through the existing template catalog entry; it is not a public capability. wizard.md explains this source and preserves user-run execution.

All new procedure overrides bind their frozen base SHA-256 in adaptations/manifest.json. No Pi frozen resource, original baseline, host state format or workflow edge changed. These are mixed selected semantics, not a claim of complete upstream synchronization.

## Matt upstream follow-up · 2026-10-17

Inspected Matt skills b0618bc436ad893b3c5e84e55fba86586d34a404 through 49dd158d1076134a641b33efb035946536778336 (two commits, three changed files). The local wizard template now incorporates plain double-quoted dotenv readback, ANSI fallback when tput clear fails, shell-variable assignment after write_env, the run_wizard execution wrapper and removal of the unused RED color. Per-item upstream path, commit and SHA-256 are recorded in core/local-manifest.json. Local EOF rejection, symlink refusal and Bash 3.2 literal single-quote handling remain in place. wizard.md preserves the wrapper when authoring stages. The original frozen template is unchanged.

The retro clarification in .out-of-scope/lazy-load-writing-for-agents.md is already satisfied: the effective retro instructions load writing-for-agents before inspecting the session, including read-only reports. No retro behavior change or new public capability is introduced. Complete disposition and local verification: docs/reviews/UPSTREAM-MATT-20261017.md.

Independent review of that candidate found that upstream's new write_env assignment shadows caller variables named key/value/tmp/sq and can print the assigned value as the recorded key. The local review fix uses function positional parameters instead of named locals, preserving the public KEY/VALUE interface and Bash 3.2 support. This is an additional local adaptation, not part of the pinned upstream source. Review-fix verification: docs/reviews/UPSTREAM-MATT-20261017-REVIEW-FIX.md.

## 2026-10-23 complete fixed-range disposition

Pi source: https://github.com/FradSer/pi-packages, commit 5a5c3a3fd38c0760553070b09c94ef2c7b5ffa44, packages/matt-pocock/procedures/grilling.md. The local grilling adaptation takes the design-tree, frontier and round model while retaining one actual decision per native question, existing approvals, independent-capability boundaries and unanswered-remains-pending behavior. Pi's required recommendation/deadline adoption and standalone textual fallback are deliberately not imported. The adaptation is bound to the unchanged frozen resources/grilling.md SHA-256; the upstream source hash and complete 104-record disposition are in evidence/implementation/upstream-upgrade-20261023/content/inventory.json.

The diagnosing-bugs catalog disclosure adds the existing hitl-loop.template.sh asset. Reference loading returns data only and does not execute the script or change saved workflow/question state. Existing 2026-10-08/17 adaptations, including wizard protections, remain intact. Matt 49dd158d1076134a641b33efb035946536778336 → 5beb35b040e3de97e54fa9e386d7e42d15c295c2 changes only the experimental chief-of-staff wiki and its changeset; both are excluded from this update. Software Factory remains deferred. Neither fixed upstream source is claimed to be fully byte-synchronized.
