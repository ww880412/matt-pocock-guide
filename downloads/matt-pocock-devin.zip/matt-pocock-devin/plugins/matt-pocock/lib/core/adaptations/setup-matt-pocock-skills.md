## 本地采纳补充 · 2026-10-08

以下约束优先于正文中不一致的默认步骤；已有用户授权与项目约定继续有效。

先核对当前 tracker、标签与命令版本；既有明确选择直接沿用。模板从本插件 action=reference 读取有效适配后的资料，不复制冻结根目录的旧模板。标签映射确定后查询实际标签，只在已有目标仓库写入授权涵盖时创建缺失标签；不重命名或覆盖用户现有标签。无远端写入授权时交付待执行清单，不把本地配置生成当远端设置完成。实际创建方式从对应 tracker 模板取得，避免要求应用尚不存在的 label。

# Setup Matt Pocock's Skills

Scaffold the per-repo configuration that the engineering skills assume:

- **Issue tracker** — where issues live (GitHub by default; local markdown is also supported out of the box)
- **Triage labels** — the strings used for the five canonical triage roles
- **Domain docs** — where the selected domain glossary/map and ADRs live, and the consumer rules for reading them. The required `domain-docs` resource is the authority for naming and source selection.

This is a prompt-driven skill, not a deterministic script. Explore, present what you found, confirm with the user, then write.

## Process

### 1. Explore

Look at the current repo to understand its starting state. Read whatever exists; don't assume:

- `git remote -v` and `.git/config` — is this a GitHub repo? Which one?
- `AGENTS.md` and `CLAUDE.md` at the repo root — does either exist? Is there already an `## Agent skills` section in either?
- `GLOSSARY.md` and `GLOSSARY-MAP.md`, plus legacy `CONTEXT.md` and `CONTEXT-MAP.md`, at the repo root; follow project conventions and any authority pointers before selecting a source. Discover existing references in `docs/agents/domain.md` and relevant maps.
- `docs/adr/` and any `src/*/docs/adr/` directories
- `docs/agents/` — does this skill's prior output already exist?
- `.scratch/` — sign that a local-markdown issue tracker convention is already in use
- Is the `triage` skill installed? (a `triage` skill folder alongside this one, or `triage` in your available skills.) This decides whether Section B runs at all.
- Monorepo signals — a `pnpm-workspace.yaml`, a `workspaces` field in `package.json`, or a populated `packages/*` with its own `src/`. Present only in a genuinely large multi-package repo; their absence means single-context, which is almost every repo.

### 2. Present findings and ask

Summarise what's present and what's missing. Then take the sections in order — one section, one answer, then the next.

Lead each section with the recommended answer so the user can accept it in a word. Give a one-line explainer only when the choice genuinely branches; skip the section entirely when exploration already settled it (Section B when `triage` isn't installed, Section C when there's no monorepo).

**Section A — Issue tracker.**

> Explainer: The "issue tracker" is where issues live for this repo. Skills like `to-tickets`, `triage`, `to-spec`, and `qa` read from and write to it — they need to know whether to call `gh issue create`, write a markdown file under `.scratch/`, or follow some other workflow you describe. Pick the place you actually track work for this repo.

Default posture: these skills were designed for GitHub. If a `git remote` points at GitHub, propose that. If a `git remote` points at GitLab (`gitlab.com` or a self-hosted host), propose GitLab. Otherwise (or if the user prefers), ask directly in the conversation and wait for the reply. Offer:

- **GitHub** — issues live in the repo's GitHub Issues (uses the `gh` CLI)
- **GitLab** — issues live in the repo's GitLab Issues (uses the [`glab`](https://gitlab.com/gitlab-org/cli) CLI)
- **Local markdown** — issues live as files under `.scratch/<feature>/` in this repo (good for solo projects or repos without a remote)
- **Another tracker** (Jira, Linear, etc.) — the user describes the workflow in one paragraph; record it as freeform prose

Record the choice in `docs/agents/issue-tracker.md`. The GitHub and GitLab templates carry a "PRs as a request surface" flag, defaulted **off** — leave it off and don't raise it; a user who wants external PRs in the triage queue can flip the flag in the file later.

**Remote prerequisite for GitHub/GitLab.** A remote tracker needs a reachable repository belonging to the user's intended project. Compare `git remote -v` with the existing tracker choice; preserve an already-confirmed target. If no remote points at the selected host, obtain the actual repository URL and show the proposed local setup. An `origin` that points elsewhere is not permission to replace it: agree a new remote name or use the explicitly selected repository for CLI calls.

Only with explicit authorization for those local configuration writes may you run `git init` (if this directory is not a repository) and `git remote add <agreed-name> <url>`. Never replace an existing remote, create a remote repository, install a CLI, or alter authentication as an implicit setup step. If the directory is inside another repository, establish the intended project root first. After any authorized setup, verify from this directory with `gh repo view --json nameWithOwner,url` / `glab repo view` and compare the returned project with the confirmed target; use an explicit repository argument when remote inference is ambiguous. An accessible upstream is not the user's target: never select `mattpocock/skills` merely because these skills came from it. If access, tooling, permission or target selection is missing, report that prerequisite and keep remote-dependent setup pending; local draft files are not evidence of remote setup success.

**Section B — Triage label vocabulary.** Skip this section entirely if the `triage` skill isn't installed (exploration told you) — an uninstalled skill needs no labels.

If it is installed, ask exactly one question directly in the conversation and wait for the reply:

> "Do you want to keep the default triage labels?" — keep the defaults (Recommended) / use my own label names

The defaults are the five canonical roles, each label string equal to its name: `needs-triage`, `needs-info`, `ready-for-agent`, `ready-for-human`, `wontfix`. On **yes**, write them as-is. Only if the user says no — usually because their tracker already uses other names (e.g. `bug:triage` for `needs-triage`) — collect the overrides so `triage` applies existing labels instead of creating duplicates.

**Section C — Domain docs.** Apply the required `domain-docs` compatibility rules first. Project conventions and the selected existing source prevail, whether named `CONTEXT` or `GLOSSARY`. Default the layout to **single-context** with the selected glossary + `docs/adr/`; for a new glossary use the shared rule's `GLOSSARY.md` default only when its creation conditions are met. Setup can record the consumer rules without inventing terms or creating a second source.

Offer **multi-context** — a selected root map pointing to per-context glossaries — only when exploration found monorepo signals. Then ask which layout they want if the project has not already selected one.

For legacy names, offer an **optional migration** to `GLOSSARY.md` / `GLOSSARY-MAP.md`; keeping the current names is fully supported. Present exact source/destination paths and affected references before writing. Only after the user's explicit authorization may you `git mv` the selected legacy files and rewrite their references in `docs/agents/domain.md`, the selected map, and any other references included in the approved plan. Never overwrite a migration destination or copy a second SSOT. If both naming schemes exist, follow the shared authority-resolution rules; do not assume the newer name wins. Keep project-defined names unless the user explicitly authorizes changing that convention too. When migration is declined or unanswered, retain the selected source and naming.

### 3. Confirm and edit

Show the user a draft of:

- The `## Agent skills` block to add to whichever of `AGENTS.md` / `CLAUDE.md` is being edited (see step 4 for selection rules)
- The contents of `docs/agents/issue-tracker.md`, `docs/agents/domain.md`, and `docs/agents/triage-labels.md` (the last only when `triage` is installed)

Let them edit before writing.

### 4. Write

**Pick the file to edit:**

- If `AGENTS.md` exists, edit it.
- Else if `CLAUDE.md` exists, edit it.
- If neither exists, ask directly in the conversation whether to create `AGENTS.md` or `CLAUDE.md`, and wait for the reply.

Prefer `AGENTS.md` when both exist. Never create a second instruction file when one already exists — always edit the existing file.

If an `## Agent skills` block already exists in the chosen file, update its contents in-place rather than appending a duplicate. Don't overwrite user edits to the surrounding sections.

The block:

```markdown
## Agent skills

### Issue tracker

[one-line summary of where issues are tracked]. See `docs/agents/issue-tracker.md`.

### Triage labels

[one-line summary of the label vocabulary]. See `docs/agents/triage-labels.md`.

### Domain docs

[one-line summary of layout — "single-context" or "multi-context"]. See `docs/agents/domain.md`.
```

Include the `### Triage labels` sub-block, and write `docs/agents/triage-labels.md`, only when `triage` is installed and Section B ran. When it isn't, both are omitted.

Then write the docs files using the seed templates in this skill folder as a starting point:

- [issue-tracker-github.md](./issue-tracker-github.md) — GitHub issue tracker
- [issue-tracker-gitlab.md](./issue-tracker-gitlab.md) — GitLab issue tracker
- [issue-tracker-local.md](./issue-tracker-local.md) — local-markdown issue tracker
- [triage-labels.md](./triage-labels.md) — label mapping (only if `triage` is installed)
- [domain.md](./domain.md) — domain doc consumer rules + layout

For "other" issue trackers, write `docs/agents/issue-tracker.md` from scratch using the user's description.

## CRITICAL: Confirm before writing, never duplicate

This is prompt-driven: present findings, ask directly in the conversation section by section, show the draft, and wait for the user's approval before anything is written. Prefer `AGENTS.md` when both instruction files exist; update an existing `## Agent skills` block in place rather than appending a duplicate.

### 5. Done

Report the files actually written and any verified remote prerequisite, then say setup is complete only when the selected setup steps have succeeded. Identify pending prerequisites or unapproved writes as remaining; do not claim success from a draft alone. Explain which engineering skills will read the completed files. Mention they can edit `docs/agents/*.md` directly later — re-running this skill is only necessary if they want to switch issue trackers or restart from scratch.
