Use a **teammate when the teammate facility is available** to do the research, so the main conversation stays focused while it reads. Otherwise do the research in the current context.

Start every new sub-agent with a fresh context window; do not fork the parent conversation. Give it a bounded task brief with explicit spec and evidence pointers, file scope, and expected output. On Codex, use `spawn_agent` with `fork_turns="none"` only when the current tool schema supports it. On other hosts, use their supported fresh-context controls; do not copy Codex parameters to Claude or Devin. If fresh-context delegation is unavailable, follow this skill's existing delegation limits or sequential fallback and disclose the limitation; do not claim an isolated agent ran. The brief identifies the research question, primary-source starting points, and findings-file destination.

Its job:

1. Investigate the question against **primary sources** — official docs, source code, specs, first-party APIs — not a secondary write-up of them. Follow every claim back to the source that owns it.
2. Write the findings to a single Markdown file, citing each claim's source.
3. Save it where the repo already keeps such notes; match the existing convention, and if there is none, put it somewhere sensible and say where.

## CRITICAL: Primary sources only

Investigate against primary sources — official docs, source code, specs, first-party APIs — never a secondary write-up of them. Follow every claim back to the source that owns it, and cite each claim's source in the findings file.
