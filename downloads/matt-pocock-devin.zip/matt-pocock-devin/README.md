# Matt Pocock for Devin CLI — 0.1.2+devin.20261009

This archive contains the self-contained Devin package. Extract it to a stable directory. Inspect the existing installation first, and record its source path so it can be restored:

```sh
devin plugins info matt-pocock
devin plugins install --local /absolute/path/matt-pocock-devin/plugins/matt-pocock
```

Review `SHA256SUMS`, the plugin manifest, MCP server and hooks before trusting the package. Use your existing Devin login; this bundle contains no credentials or user configuration. Follow the host's trust prompts. Keep the old package and session state; do not overwrite a modified installation or remove an existing plugin merely to make this command succeed.

Guide: https://ww880412.github.io/matt-pocock-guide/guide.html

Interactive questions require the validated TTY path. Package verification does not establish real-host or human-interaction acceptance. Consult the release's stated evidence and limitations.
