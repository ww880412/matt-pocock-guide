---
name: matt-pocock
description: Route and manage Matt Pocock engineering workflows; discover and independently use bundled capabilities
---

# Matt Pocock workflow entry

Usage: /matt-pocock:matt-pocock <route | status | transition | transition <procedure> | end | request text>

Routes: idea-to-ship, hard-bug, triage, wayfinding, architecture.

This command is applied by a host hook before you read this file: the hook has already started, transitioned, or ended the workflow (or reported its status) and has injected any procedure text and instructions as additional context. Do not re-apply the command with tools, do not call matt_pocock_workflow to reproduce it, and do not summarise this file to the user. Follow the injected context.

## 可选写作路线

/matt-pocock:matt-pocock writing：采集素材。已有素材可直接调用 workflow 工具，route=writing，procedure=writing-shape 或 writing-beats；三阶段任选，不强制串行。

## 能力目录与独立调用

- /matt-pocock:matt-pocock skills：查看带用途和产出的能力目录。
- /matt-pocock:matt-pocock skills <任务描述>：按自然语言推荐能力，说明理由并等待用户选择。
- /matt-pocock:matt-pocock use <能力名称> [任务]：独立调用选定能力，保留当前工作流。

skills、use 和入口自由文本由 hook 注入 matt_pocock_skill 工具指令，尚未调用能力工具；执行该指令一次。上文的 do not re-apply 仅禁止重复已执行的工作流状态命令，不禁止此能力工具调用。
独立调用只完成选定能力；即使原工作流活跃，也不自动切换或推进它。追问使用返回正文指定的 capability 参数。模板和内部参考不是公开能力。
