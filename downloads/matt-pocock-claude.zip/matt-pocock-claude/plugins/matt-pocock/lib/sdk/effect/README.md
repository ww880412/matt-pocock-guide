# Effect command protocol

`openEffect({stateRoot})` creates the optional external-effect module. It depends
only on the SDK kernel and Node standard library. All processes targeting the same
resource must share this state root; resource journals use a host-independent
`resources` tree and `resource:<name>` envelope scope.

The kernel's `openStore({stateRoot})` and `openEffect({stateRoot})` must use the
same stateRoot. Different roots do not share journals or locks, so calls and
commands will not exclude each other even when their resource names match.

```js
const effects = openEffect({stateRoot});
const result = await effects.execute({
  resource: canonicalTarget,
  identity: {round, candidateDigest, target: canonicalTarget},
  inputBindings: prepared.command.inputBindings,
  verify: ref => trustedArtifactOrReceiptVerifier(ref),
  invoke: command => engineAdapter.deploy(command.identity),
  classify: error => provenPreEffectCode(error) ? 'preEffect' : 'unknown',
  reconcile: command => engineAdapter.readOnlyStatus(command),
});
```

Identity is JSON data canonicalized by sorted object keys. It identifies the
business target and input version, **never the authorization receipt**. The
constructor and function ports are trusted integration code, not model tool
arguments. `inputBindings` must come from the kernel's prepared command; every
reference is checked before accepting a new attempt. An already succeeded
identity reuses its stored result before binding verification, even if those
bindings are now stale; the result does not authorize a new external invocation. The effect module alone does
not grant user authority.

`execute` returns `status: succeeded | failed | unknown | rejected`. Successful
reuse includes `reused: true`; rejection includes `code`; unknown can include a
`missing` list. `records(resource)` reads durable command events for auditing.
These are internal command results; adapters may map them to their public Outcome.

Each attempt writes separate fsynced `intent`, `executing`, and terminal events.
Resource locks cover these writes, never the awaited engine call or reconciliation.
A live or unassessable owner cannot be taken over. A provably dead intent is marked
abandoned and can retry with a new attempt. A dead executing command is reconciled
without calling the engine again. A completed command is reused even after a new
confirmation, even when its bindings have become stale. Unknown outcomes block
the entire resource, including different identities. For supported human and
system resolution, see [Resolving an unknown effect](../CALLS.md#resolving-an-unknown-effect).
Resolution records checked evidence under the resource lock; it is not an
unconditional override or automatic retry. Corrupt journals fail closed.

`classify` must prove an error happened before **any** external effect to return
`preEffect`. Exit codes alone are insufficient. Reconciliation must establish all
outputs; absent a trustworthy engine-owned query it returns unknown. This prevents
repeating confirmed or uncertain operations; it does not promise exactly-once
execution or coordinate unrelated software that bypasses the plugin.


## Explicit resolution context (0.4 candidate)

`resolve(request, context)` forwards context only to the trusted constructor port
`authorizeResolution(request, context)`. The default remains agent/denied. Supply
context from an already checked kernel event port, e.g. `{authority: ctx.authority}`;
never from model/tool claims. Existing one-argument ports work unchanged.
Use `kernel.verifyDecisionRef(owner, request, ref)` to recheck decision input bindings
before execute; additional artifact bindings need their own verifier. See
[CALLS](../CALLS.md) for current binding, completion and resource checks.
