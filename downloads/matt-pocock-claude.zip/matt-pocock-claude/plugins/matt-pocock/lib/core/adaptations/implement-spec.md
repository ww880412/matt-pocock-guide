---
name: implement-spec
description: Implement an approved spec and its ticket graph on one integration candidate.
disable-model-invocation: true
---

Implement the result of to-spec and to-tickets. The output is the entire approved spec on one integration branch or an explicitly identified scoped candidate, with per-ticket evidence and honest unresolved work. This is a prompt-driven coordination protocol using the current host's available tools, not a persistent scheduler.

## Inputs and authority

Read the spec, scenarios, ticket tracker and its closing rules, project instructions, repository baseline and existing user authorization. If tracker configuration is missing, inspect project conventions and ask only for an unresolved choice; do not automatically run setup or install anything. A local tracker can finish with a local integrated candidate and local ticket evidence; a PR is not mandatory.

Record the original branch/tip, dirty and untracked user files, integration base, scoped paths, safe checks and authorization boundaries. Reuse explicit authorization already given for this task. Creating a draft PR, pushing, marking ready, closing external tickets, committing, installing dependencies and changing configuration each require coverage by that authorization; skill invocation alone grants none. If absent, continue authorized local work and preserve the candidate and proposed external changes without claiming them executed. If integration needs commits that are not authorized, retain scoped worktree snapshots and explain the specific integration operation awaiting authorization; do not call the task integrated or complete.

Use the host's available agent, wait, worktree, Git and tracker tools. On Codex, discover the supported collaboration and managed-worktree tools; on Claude, use its supported Agent/background, worktree and shell interfaces. Do not invent commands or assume background execution exists. If required isolation or delegation is unavailable, report the limitation, preserve work and agree a feasible execution mode before claiming this protocol ran.

## Validate and dispatch the task graph

Read ticket IDs, scope, dependencies and acceptance evidence. Reject cycles, unknown blockers, duplicate IDs and overlapping ownership before dispatch. Maintain a task-local ledger (a task artifact, not new plugin state): ticket, blockers, unique owner, branch/worktree, starting integration tip, status, evidence, integrated revision and remaining issue. Statuses distinguish queued, running, failed, blocked, ready-to-integrate, integrated and verified. Completion counts are not proof of acceptance.

The ready frontier contains only unclaimed tickets whose blockers are integrated and verified. Appoint one integration owner; shared files and dependent changes have explicit serialization. Claim each ticket once with a unique owner before spawning its implementer. Dispatch only the ready frontier; communicate through spec/ticket/research pointers and bounded local-check instructions. Optional exploration can save accessible notes outside the repo, without copying sensitive material.

Each implementer uses a separate task-owned worktree and branch based on the recorded integration tip. Verify path, ownership, cleanliness and base before editing. Never reset, clean, overwrite or delete user dirty work. If the base is wrong, preserve it and create a correctly based task worktree instead. Use host branch naming conventions. Load tdd through matt_pocock_skill action=reference, context=implement-spec, id=tdd (or its mapped host tool), then perform real red-green slices at the agreed seams. Run only assigned local checks; the integration owner owns shared checks.

## Serial integration and failure

An implementer safely incorporates the latest integration tip in its own worktree before reporting ready, preserving its own work and handling conflicts. Report actual commands, test outcomes, base, candidate and unresolved issues. A report is not an accepted merge and does not guarantee fast-forward.

Only the integration owner mutates the integration branch, in serial order (a merger agent may act under that owner's exclusive assignment). At receipt, re-read the latest integration tip and compare it with the worker's tested base. If another worker integrated meanwhile, reconcile again against the current tip, resolve conflicts preserving both intents, and rerun affected checks. Never assume a stale worker completion guarantees a clean merge. Record before/after tips, worker revision or scoped fingerprint and validation. Repeated completion reports for the same ticket/candidate do not trigger a second integration. A changed candidate requires an explicit rework assignment.

A failed worker, failing test or unresolved conflict leaves the ticket failed/blocked, with error evidence and safe worktree retained. Its dependents never enter the ready frontier. Independent ready work may continue within scope. Do not silently retry indefinitely or mark failed work complete; record the bounded retry/reassignment and invalidate superseded evidence. Recompute the frontier only after integration and applicable validation.

## Pause, resume and review

On user pause or a blocking interruption, stop new dispatch, establish the actual state of running workers with supported host tools, and save the ledger, candidate/tips, worktree ownership, outstanding worker IDs, authorization, failed checks, unresolved conflicts and next safe action. Do not report all tickets complete. On resume, reread Git, tracker and worker state rather than trusting old summaries; reconcile claims and completed candidates before dispatch so work is neither lost nor integrated twice. Plugin workflow checkpoints can point to these artifacts; they do not restart agents automatically.

When all tickets are integrated, load code-review via matt_pocock_skill action=reference, context=implement-spec, id=code-review. Give Standards and Spec reviewers the same candidate and original baseline, the full spec/scenarios and ticket evidence. Run shared repository checks on that candidate. Use one bounded implementer for review corrections; identify the changed candidate, rerun affected checks and explicitly dispatch re-review. Required returned reports, resolved blocking findings and verification must all cover the same candidate before delivery.

If the tracker closes through PRs or the user asks for a PR, and external actions are authorized, create a draft only after the first actual integration produces a nonempty diff; include spec/ticket references. Mark ready and close tickets only according to tracker rules after review and checks pass. Otherwise report the integration branch/candidate and resolve the local tracker within the task's authorized scope. Keep publication pending when unauthorized; never invent a remote result.

Clean up only verified task-owned worktrees whose results and recovery evidence are preserved and whose workers have stopped. Preserve failed/unmerged work and every user worktree. Report implemented/blocked tickets, candidate, validation, review and delivery status separately. After code-review, retro is optional; handoff can preserve unfinished work. Stage loading does not itself prove execution or authorize publication.
