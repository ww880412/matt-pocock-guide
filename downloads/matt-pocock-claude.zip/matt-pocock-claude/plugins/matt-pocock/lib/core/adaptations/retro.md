---
name: retro
description: Suggest evidence-backed improvements to the coding agent environment after a session.
disable-model-invocation: true
---

The user requested a retrospective. Produce suggestions only: this invocation does not edit checks, instructions, memory, hooks or configuration, install tools, publish, or change workflow state. A later explicit implementation request can authorize selected changes; do not interpret advice to build a check as authority to build it now.

1. Load writing-for-agents using matt_pocock_skill action=reference, context=retro, id=writing-for-agents (mapped to the current host's tool name).
2. Read primary sources for the explicitly specified session, defaulting to the current session. Use current conversation evidence, supported session-read tools or user-specified accessible logs. Do not search unrelated private sessions or extract credentials. State inspected session, time/turn range and missing/truncated evidence. If logs are unavailable, report the limited evidence; do not infer tool failures, latency or causality from a final summary. Separate observations from inferences and unknowns.
3. Inspect existing checks first: the project's lint/check/test scripts, build tool, CI and relevant hook/config wiring. Distinguish a missing check, an existing but unwired/broken check, and a check already covering the problem. A missing hook or CI is not automatically a severe defect: inspect alternative controls and observed impact.
4. Examine the categories below against actual session evidence. Rank supported candidates by impact/severity, giving each: observed event and source pointer → effect → existing control/instruction → minimal proposed improvement → validation method. Distinguish system/tool reliability, model judgement and user/business outcome. Do not label speculation as an observed failure.

- Navigation: slow file discovery, hidden dependencies or missing pointers; prefer a pointer to existing docs over duplication.
- Automated checks: mechanical violations (fixed syntax, banned API/import shape/file placement) belong in deterministic checks. Recommend repairing existing checks before proposing a duplicate tool. Recommend a new check only where a real gap remains; implementation is a separate action.
- Coding standards: reserve CODING_STANDARDS.md for judgement calls such as cross-file consistency or contextual style. Reviewers have less exploration/context pressure and should enforce these standards; do not overload implementers with all review rules.
- Global AGENTS.md / CLAUDE.md: identify excessive steering that could become a navigation pointer or an appropriate project check/standard. Propose changes only, including to global files.
- Tool economy: substantiate costly calls with observed events; suggest fewer or more focused calls without inventing timing.
- No-ops: identify instructions that demonstrably failed to affect behaviour or duplicate a stronger rule; separate inference when effect is uncertain.
- Information access: suggest scoped read-only access or logs where evidence was missing. Do not acquire access, alter credentials or run setup during retro.

Present candidates in severity order with evidence and limits; an empty supported finding set is valid. AGENTS.md/CLAUDE.md should remain sparse navigation; existing docs and skills are preferred reference surfaces. Standards files over 1,000 lines can use pointers, but length alone is not proof of harm. Keep the original workflow and pending questions intact for independent invocation. As an optional idea-to-ship stage, deliver the report before completion or handoff; no recommendation automatically becomes an implementation task.
