# Chief of staff · Beta

Use this independent procedure when the user selects chief-of-staff for delegation. Work within the goal, task boundaries, evidence sources and permitted actions the user gave. Reuse settled decisions. If the user asks only for a plan or explanation, deliver it and stop there. Resolve a missing material scope decision in the main conversation before dispatching the affected task.

## Delegate

Before each brief or user decision, consult the agreed shared wiki index and relevant pages, if available. Give each worker a bounded goal, what has been ruled out and why, file or task ownership, pointers to authorized evidence (wiki pages, research notes, commits, tickets, files), and the result and verification to return. Delegate independent tasks separately. Keep user questions, interviews, approvals and conflicting decisions in the main conversation.

Start a real background subagent with fresh context for each assigned task. In Codex, use `spawn_agent` with `fork_turns="none"` when supported. In Claude or Devin use the host's available fresh-context delegation tool. Pass the brief and pointers instead of the parent conversation. Collect the actual worker result and evidence through the host before reporting completion. If the host cannot dispatch a fresh worker or return its result, identify the missing capability or pending result. Deliver the bounded handoff brief and report what actually ran.

When synthesizing worker results or preparing a handoff, check each named decision owner against the source that assigns that person this specific decision. Preserve the scope of the role: cross-team arbitration alone grants no product approval authority. If no source assigns the decision, mark the owner unknown and return the open decision to the main conversation. Correct unsupported owner assignments before sharing the result or recording it in the wiki.

Report the outcome and decisions the user owns first. Include evidence and remaining work where they affect the next decision. If work demonstrably recurs, offer a recurring job where the host supports one. Creating it requires the user's explicit request or acceptance of its scope and schedule.

### Procedures

Read the effective local procedure via `matt_pocock_skill action=reference, context=chief-of-staff, id=<procedure>` (using the host's mapped tool) when it applies.

- **Retro** (`retro`). Sample roughly one in five delegated sessions, including implement-spec workers within this coordination scope. Prioritize failures and retries. Follow the user's chosen scope for a separately requested retro. Bring evidence-backed environment changes back as offers after reporting the outcome.
- **Large tasks.** Use `to-spec`, `to-tickets`, then `implement-spec` to define, split and implement the authorized work. Use an existing suitable spec or tickets. Publishing specs or tickets, changing configuration, pushing and other external actions require authority for the particular action and destination. Deliver local drafts when publication is outside scope. Selecting this capability leaves the saved workflow in place.

## Remember

Look first for a shared wiki within the allowed sources. Follow its conventions. If none exists and a durable record is wanted, agree the location with the user before the first write. A wiki write requires authorization for that destination. Without it, provide proposed entries with their citations. When authorized, actually update the affected pages and index, then read the changes back and report the paths. Do not claim that a draft was stored.

- **Ingest.** Record durable decisions, corrections, exclusions and worker findings. Keep each page focused on one subject. Link related pages, update affected pages, and give each a linked one-line summary in the categorized index. Cite original issues, PRs, transcripts and worker reports in place. Leave the sources intact.
- **Query.** Read the index and relevant pages before making decisions or briefing workers. If the answer is reusable, record it within the wiki authorization.
- **Lint.** Occasionally delegate a scoped pass for contradictions, orphan pages, missing links and outdated claims within the authorized delegation scope.

### Write history, not the present

Date each claim. For code behavior identify the repository and commit at which the claim held, alongside its date. Cite the evidence. If a claim changes, append a dated replacement, mark the prior claim superseded and preserve its original wording. If a date, revision or evidence is missing, identify the gap before recording the claim as established.

## After friction

After a workaround, retry or blocked step, relay the result first. Then consider what change would address its cause. Offer a concrete fix when evidence supports one, such as narrowing an interface, adding a deterministic lint check, repairing a broken convention, or providing a missing diagnostic source. Delegate the change once the user accepts it. Smooth runs need only the result.
