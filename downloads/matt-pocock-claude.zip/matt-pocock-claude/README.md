# Matt Pocock for Claude Code — 0.1.1

This archive contains the self-contained Claude Code package. Extract it to a stable directory and launch Claude Code with the plugin directory (replace the example path):

```sh
claude --plugin-dir /absolute/path/matt-pocock-claude/plugins/matt-pocock
```

Review `SHA256SUMS`, the plugin manifest, MCP server and hooks before trusting the package. Use your existing Claude login; this bundle contains no credentials or user configuration. Follow the host's trust prompts; extraction does not grant approval. Keep the previous package and user state until the new version has been accepted. Do not overwrite a modified installation.

Guide: https://ww880412.github.io/matt-pocock-guide/guide.html

Package verification does not establish real-host or human-interaction acceptance. Consult the release's stated evidence and limitations.
