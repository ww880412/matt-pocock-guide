// Installer companion. Review is read-only; --approve requires the user's explicit
// consent to the exact review shown in the conversation. Never run this from a hook.
import { spawn } from 'node:child_process';
import { createInterface } from 'node:readline';
import { createHash } from 'node:crypto';
import { homedir } from 'node:os';
import { resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const purposes = {
  sessionStart: '开始或恢复任务时，加载本插件已保存的工作流状态。',
  userPromptSubmit: '发送消息时，识别本插件入口并补充当前工作流指引。',
};

export function reviewHooks(response, { pluginId, configHome, cwd }) {
  const row = response.data?.find(row => resolve(row.cwd) === resolve(cwd));
  if (!row || row.errors?.length || row.warnings?.length) throw new Error('Hook discovery is incomplete; resolve its warnings/errors before approval.');
  const candidates = row.hooks.filter(h => /^matt-pocock@[A-Za-z0-9_-]+$/.test(h.pluginId ?? ''));
  const ids = [...new Set(candidates.map(h => h.pluginId))];
  if (ids.length !== 1 || (pluginId && ids[0] !== pluginId)) throw new Error('Expected one enabled Matt Pocock installation; resolve missing or duplicate installations first.');
  const hooks = candidates.sort((a, b) => a.key.localeCompare(b.key));
  if (hooks.length !== 2 || new Set(hooks.map(h => h.eventName)).size !== 2 || hooks.some(h =>
    !purposes[h.eventName] || h.source !== 'plugin' || h.isManaged || h.handlerType !== 'command' ||
    !h.key.startsWith(`${ids[0]}:hooks/hooks.json:`) || !/^sha256:[a-f0-9]{64}$/.test(h.currentHash) ||
    !h.command || !h.sourcePath
  )) throw new Error('Unexpected hook definitions; do not approve automatically.');
  const definitions = hooks.map(h => ({
    key: h.key, eventName: h.eventName, command: h.command, sourcePath: h.sourcePath,
    currentHash: h.currentHash, enabled: h.enabled, matcher: h.matcher,
    timeoutSec: h.timeoutSec, async: h.async,
  }));
  const reviewToken = createHash('sha256').update(JSON.stringify({
    configHome: resolve(configHome), cwd: resolve(cwd), definitions,
  })).digest('hex');
  return {
    pluginId: ids[0], reviewToken,
    ready: hooks.every(h => h.enabled && h.trustStatus === 'trusted'),
    hooks: hooks.map((h, i) => ({ ...definitions[i], purpose: purposes[h.eventName], trustStatus: h.trustStatus })),
  };
}

export async function runTrust({ request, cwd, configHome, pluginId, approve }) {
  const inspect = async () => reviewHooks(await request('hooks/list', { cwds: [cwd] }), { pluginId, configHome, cwd });
  const review = await inspect();
  if (approve === undefined) return { ...review, status: review.ready ? 'ready' : 'needs_user_confirmation', written: false };
  if (approve !== review.reviewToken) throw new Error('Review changed or approval token is invalid. Show a fresh review and obtain new user consent. No trust was written.');
  if (review.ready) return { ...review, status: 'ready', written: false };
  const edits = review.hooks.flatMap(h => {
    // Quote the whole hook key as one TOML path component; never edit other hooks.
    const prefix = `hooks.state.${JSON.stringify(h.key)}`;
    return [
      { keyPath: `${prefix}.trusted_hash`, value: h.currentHash, mergeStrategy: 'replace' },
      { keyPath: `${prefix}.enabled`, value: true, mergeStrategy: 'replace' },
    ];
  });
  await request('config/batchWrite', { edits, reloadUserConfig: true });
  const verified = await inspect();
  if (!verified.ready || verified.hooks.some((h, i) => h.key !== review.hooks[i].key || h.currentHash !== review.hooks[i].currentHash || h.command !== review.hooks[i].command)) {
    throw new Error('Trust settings were written, but verification did not pass. Inspect the current hooks; do not report installation complete.');
  }
  return { ...verified, status: 'ready', written: true };
}

// Small stdio client, with no model turn and no hook execution.
function connect(command, cwd) {
  const child = spawn(command, ['app-server'], { cwd, stdio: ['pipe', 'pipe', 'pipe'] });
  let next = 0;
  const pending = new Map();
  const fail = error => {
    for (const item of pending.values()) { clearTimeout(item.timer); item.reject(error); }
    pending.clear();
  };
  child.on('error', fail);
  child.on('exit', () => fail(new Error('Codex app-server exited before completing the request.')));
  child.stderr.resume();
  const send = msg => child.stdin.write(JSON.stringify({ jsonrpc: '2.0', ...msg }) + '\n');
  createInterface({ input: child.stdout }).on('line', line => {
    let msg;
    try { msg = JSON.parse(line); } catch { return; }
    if (msg.method && msg.id !== undefined) {
      send({ id: msg.id, error: { code: -32601, message: 'This installer only supports configuration requests.' } });
      return;
    }
    const item = pending.get(msg.id);
    if (!item) return;
    pending.delete(msg.id); clearTimeout(item.timer);
    if (msg.error) item.reject(new Error(msg.error.message)); else item.resolve(msg.result);
  });
  return {
    request: (method, params) => new Promise((resolve, reject) => {
      const id = ++next;
      const timer = setTimeout(() => { pending.delete(id); reject(new Error(`Codex request timed out: ${method}`)); }, 25000);
      pending.set(id, { resolve, reject, timer }); send({ id, method, params });
    }),
    notify: method => send({ method, params: {} }),
    close: () => { child.stdin.end(); const timer = setTimeout(() => child.kill('SIGKILL'), 1500); timer.unref(); },
  };
}

export async function main(args = process.argv.slice(2)) {
  const options = { cwd: process.cwd(), configHome: process.env.CODEX_HOME || resolve(homedir(), '.codex') };
  let codex = 'codex';
  for (let i = 0; i < args.length; i++) {
    const arg = args[i];
    if (arg === '--review') continue;
    if (!['--approve', '--plugin', '--codex'].includes(arg) || !args[i + 1] || args[i + 1].startsWith('--')) throw new Error('Usage: node scripts/trust-hooks.mjs [--review | --approve REVIEW_TOKEN] [--plugin matt-pocock@MARKETPLACE] [--codex PATH]');
    const value = args[++i];
    if (arg === '--approve') options.approve = value;
    if (arg === '--plugin') options.pluginId = value;
    if (arg === '--codex') codex = value;
  }
  const rpc = connect(codex, options.cwd);
  try {
    await rpc.request('initialize', { clientInfo: { name: 'matt-pocock-hook-installer', version: '1' }, capabilities: { experimentalApi: true } });
    rpc.notify('initialized');
    console.log(JSON.stringify(await runTrust({ ...options, request: rpc.request }), null, 2));
  } finally { rpc.close(); }
}
if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  main().catch(error => { console.error(error.message); process.exitCode = 1; });
}
