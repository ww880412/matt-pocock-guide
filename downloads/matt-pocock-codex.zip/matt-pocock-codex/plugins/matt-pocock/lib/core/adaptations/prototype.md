## 本地采纳补充 · 2026-10-08

以下约束优先于正文中不一致的默认步骤；已有用户授权与项目约定继续有效。

必须实际生成并检查可运行原型，再报告它回答的问题。结论区分实测结果、拟议的生产选择和未决政策；清楚列出未测试项。例如浮点数表示实验不证明舍入政策、并发承诺或所有边界已经确定。只有经确认的设计决定才能进入后续实现；原型交付本身不授权修改生产源码、提交或发布。

# Prototype

A prototype is **throwaway code that answers a question**. The question decides the shape.

## Pick a branch

Identify which question is being answered — from the user's prompt, the surrounding code, or by asking the user directly in the conversation if they are available:

- **"Does this logic / state model feel right?"** → [LOGIC.md](LOGIC.md). Build a single self-contained HTML file that lets anyone drive the state model through cases that are hard to reason about on paper.
- **"What should this look like?"** → [UI.md](UI.md). Generate several radically different UI variations on a single route, switchable via a URL search param and a floating bottom bar.

The two branches produce very different artifacts — getting this wrong wastes the whole prototype. If the question is genuinely ambiguous and the user isn't reachable, default to whichever branch better matches the surrounding code (a backend module → logic; a page or component → UI) and state the assumption at the top of the prototype.

## CRITICAL: The question decides the shape

Identify the question being answered before building — "does this logic / state model feel right?" takes LOGIC.md, "what should this look like?" takes UI.md; getting this wrong wastes the whole prototype. Throwaway from day one: no tests, no polish, no persistence — keep the answer, delete the code.

## Rules that apply to both

1. **Throwaway from day one, and clearly marked as such.** Locate the prototype code close to where it will actually be used (next to the module or page it's prototyping for) so context is obvious — but name it so a casual reader can see it's a prototype, not production. For throwaway UI routes, obey whatever routing convention the project already uses; don't invent a new top-level structure.
2. **Easy to run.** For a logic HTML demo, open the self-contained file directly; no install or server is required. For other forms, use one command with whatever the project's existing task runner supports — `pnpm <name>`, `python <path>`, `bun <path>`, etc. The user must be able to start it without thinking.
3. **No persistence by default.** State lives in memory. Persistence is the thing the prototype is _checking_, not something it should depend on. If the question explicitly involves a database, hit a scratch DB or a local file with a clear "PROTOTYPE — wipe me" name.
4. **Skip the polish.** No tests, no error handling beyond what makes the prototype _runnable_, no abstractions. The point is to learn something fast.
5. **Surface the state.** After every action (logic) or on every variant switch (UI), print or render the full relevant state so the user can see what changed.
6. **Capture it when done.** Fold any validated decision into the real code, then preserve the prototype as a **primary source** on a throwaway branch, out of main, and leave a context pointer to that branch on the implementation issue. Record the verdict and the question it settled in the issue or commit message. When a commit is needed, follow the repository's git-agent workflow rather than staging or committing directly. The main branch keeps only the validated decision.

## 本地交付约束

逻辑原型默认 HTML；用户明确要求终端时遵循该要求。LOGIC.md 的下方绝对路径指向本地适配附件，优先于冻结资源根目录的旧同名附件。UI 分支保持原有 UI.md。不得自动安装依赖、提交、发布或修改配置；按目标项目现有授权执行。
