# Local adaptations

Approved SN-01/SN-02; see docs/product/V2-02-SAME-NAME-SPEC.md in the source project.

Matt repository: https://github.com/mattpocock/skills
Matt commit: 3cca18b368ae95cdbdebbff572ccafa662551015
LOGIC.md derives from skills/engineering/prototype/LOGIC.md, SHA-256 f61c7d249e786a79ef289018901c348271e1798dd0b0bc5607b5c6f4d4a01ab9.
wait-what.md incorporates the CONTEXT-MAP lookup idea from skills/productivity/wait-what/SKILL.md.
prototype.md derives from the frozen Pi procedure with only the approved logic branch and host constraints adapted.
Original frozen resources and manifests are unchanged. These files are local adaptations, not byte-identical upstream copies.
MIT licenses and copyright notices: packaged lib/resources/LICENSE (Pi) and lib/resources/matt/LICENSE (Matt).

## 2026-09-25 selected update

See docs/product/UPSTREAM-20260925.md in the source project. implement.md, code-review.md and writing-for-agents.md derive from Pi commit 157c21f75481f575f3c3575dc18e6f8ee271c756, packages/matt-pocock/procedures/. Local changes adapt review dispatch to available host tools, preserve review-only scope and missing-spec UNVERIFIED, and keep commits/publication behind existing authority. Frozen Pi resource hashes remain unchanged; these adapted files do not claim to be the original baseline.

## 2026-10-02 selected update

Matt inspected commit: d81f3a183412e71a5b1e84ca21bc1a35eea03a60 (https://github.com/mattpocock/skills).
The CONTEXT/GLOSSARY naming change is adapted as the shared local resource `local/domain-docs.md`, hash-pinned in `core/local-manifest.json` and required by domain-document consumers in the catalog. It resolves existing project conventions, both maps, ambiguous coexistence and missing sources without renaming user files or creating duplicate glossaries. `wait-what.md` uses that policy. Frozen Pi originals, domain template identity and teaching templates remain unchanged.

The three `pr` resources are copied unmodified from `skills/engineering/pr/` at the inspected commit; their former `skills/in-progress/pr/` paths are retired. Per-file commit, size and SHA-256 are in `core/matt-manifest.json`. PR content preserves its in-file author credit and sibling `CREDITS.md` (Dex Horthy / Humanlayer show-me); its agent metadata is retained. The catalog and local route guidance expose the same existing independent capability as stable. Ask-matt's original source remains pinned to its earlier commit: this is selected local navigation, not a claim of full upstream synchronization. `retro` and `implement-spec` are not introduced; `resolving-merge-conflicts` remains available. SDK and host mechanisms are outside this adaptation.
