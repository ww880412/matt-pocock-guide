# Local adaptations

Approved SN-01/SN-02; see docs/product/V2-02-SAME-NAME-SPEC.md in the source project.

Matt repository: https://github.com/mattpocock/skills
Matt commit: 3cca18b368ae95cdbdebbff572ccafa662551015
LOGIC.md derives from skills/engineering/prototype/LOGIC.md, SHA-256 f61c7d249e786a79ef289018901c348271e1798dd0b0bc5607b5c6f4d4a01ab9.
wait-what.md incorporates the CONTEXT-MAP lookup idea from skills/productivity/wait-what/SKILL.md.
prototype.md derives from the frozen Pi procedure with only the approved logic branch and host constraints adapted.
Original frozen resources and manifests are unchanged. These files are local adaptations, not byte-identical upstream copies.
MIT licenses and copyright notices: packaged lib/resources/LICENSE (Pi) and lib/resources/matt/LICENSE (Matt).
