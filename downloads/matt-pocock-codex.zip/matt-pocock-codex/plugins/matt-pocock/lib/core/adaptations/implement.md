## 本地采纳补充 · 2026-10-08

以下约束优先于正文中不一致的默认步骤；已有用户授权与项目约定继续有效。

传入票据引用时，先读取正文、评论及当前状态，报出真实标题和标识后再实施；不要猜测票据内容。沿用已加载的 BDD/TDD 场景并实际执行红绿验证，加载正文不等于完成验证。修复只覆盖已确认行为；可信内部路径不得为不存在的需求增加 `??` 默认值、备用模式或吞错分支。保留现有 exports、必填输入与错误语义；必要防护须有当前可达输入或明确兼容要求支持。

Implement the work described by the user in the spec or tickets.

Use [bdd](bdd.md) at the agreed seams, one red-green slice at a time. The bundled [tdd](tdd.md) owns Automation-phase test quality, seams, and mocking guidance.

## Verification and integration

- Establish which checks are safe before execution; use isolated home, credentials and test data where needed. Do not assume local commands have no production access.
- Give implementers bounded local checks and appoint one integration owner for shared checks. Keep dependent changes ordered and conflicting writes under one owner; use the host's dependency and resource primitives when available.
- Record the task baseline, including untracked files and unrelated dirty work to exclude. After integration and local checks, identify the candidate revision or scoped snapshot. Review and final verification must inspect the same candidate; a Git commit is not required to identify it.
- Run affected tests during implementation. The integration owner runs applicable type, lint, build and broad regression checks after integration, not redundantly per Agent. Later edits invalidate affected evidence; rerun the checks and review conclusions those edits can change. Repository-required verification still applies.

Then use [code-review](code-review.md). Delivery requires the integrated candidate's applicable verification, returned blocking reviews, and findings resolved. Continue other authorized work while required reviews run. If only required Agent results remain outstanding, use the host's available wait mechanism and keep the workflow active; yield only when the result is unavailable or genuinely requires an external actor. Do not announce completion while waiting. A completed review assignment is evidence to assess, not automatically a PASS on the implementation.

Commit only when the user has authorized it; follow the repository's applicable Git workflow and available host tools. Loading this procedure does not authorize staging unrelated work, pushing, publishing, or installing dependencies.
