# Task state SDK — 0.2 reference implementation

Node.js ES modules, standard library only. The SDK is an embedded runtime; the host supplies Node. This repository's validation runtime is Node 25.4.0. The repository's prior verification environment was Node 24.13.0; this change does not claim verification on older Node versions.

## Ownership

A consumer imports `kernel/store.mjs` and `kernel/pipeline.mjs`, injects its schema, action policy and host ports, and opts into decision/effect/delivery/restore/lifecycle. No SDK file imports Matt. Matt's existing import paths are compatibility facades; its state, graph, tool definitions, text, marker codec and lifecycle action mapping stay under core/runtime/hosts/variants.

`openStore({host,stateRoot,schema,model?,namespaces?,scopeFor?})` uses the extracted file lock, fencing, fsync journal and atomic metadata implementation. Consumers create a session index only from the host hook's trusted project binding. `createKernel` requires that index before any action. Constructor ports are trusted code; never forward a tool's claimed owner, authority, proof or filesystem path into them. `createHostCapabilities` provides the three current host/channel declarations and actual identity, wire and hook payload ports.

## Optional modules

Register every selected namespace before the first metadata read after opening a store: `registerDelivery(store)` and `registerRestore(store)` are idempotent; creating the decision ledger registers decisions. Delivery and restore also register themselves at their action entrypoints and supply missing initial values. When reopening a composed consumer, register all selected modules before any one reads the shared metadata. Unknown or invalid metadata remains subject to the store corruption policy.

The planned `process: {spawn, killGroup, wallClock}` constructor port from 03 §8
is not implemented; there is currently no consumer of that port.

Restore persists `meta.restore.intentOriginKey` before handing out an append
intent. `createRestore({legacyRestored})` lets a consumer recognize pre-field
legacy restore events; the SDK does not interpret consumer `source` fields.

## Journal contract

New events are version 2: the kernel owns v, seq, eventId, at, host, projectId, sessionId and scope. `authority.kind` is agent/user-direct/user-answer/system; a user channel is not proof of a human. State-changing events carry consumer state and action. Decision and command events set stateChanging=false. All records share strict contiguous seq and the same fsync path; stateEvents, fold and generation ignore non-state records. The default envelope kinds are `transition | decision | command | system`.
A trusted consumer model may register `eventKinds` for extra kinds; Matt registers
`start | end | restore` and keeps its legacy source/kind/reason fields for public compatibility. A consumer codec interprets v1; old bytes are never rewritten and old actions do not acquire retroactive receipts.

Journal corruption is quarantined with diagnostic evidence. Effect journals fail closed rather than treating damaged history as a new resource. Locks only reclaim a provably dead owner (PID plus process start); uncertainty remains busy. Scope locks protect synchronous checks/writes only; waiting for users, invoking software and reconciliation happen outside locks. Single machine only.

## Decision and command contract

`decision/state.mjs` provides durable ownership, revision CAS, bounded terminal history and namespace registration. Matt's adapter retains its channel-specific presentation metadata and migrates nativeInput into decisions on the next permitted write. Live foreign owners are not taken over. `decision/process.mjs` retains the elicitation channel's process lifetime.

`decision/receipts.mjs` writes immutable decision receipts from trusted adapter submissions. Receipt refs contain scope/eventId/digest. The order is submitting intent → receipt fsync → dependent action → answered. Recovery first checks actionKey before binding; a recorded answer remains answered if its later action is rejected as stale. Nonanswers and extension navigation terminals do not produce receipts.

`effect/index.mjs` provides resource-scoped command attempts. Identity contains business target and input version, never receipt identity. Each state has a distinct originKey. Dead intent-only is abandoned; executing without sufficient evidence becomes unknown and is not retried. Live/unknown owners and unknown effects block competing commands. Success is reusable even with a new receipt; failed preEffect/abandoned attempts may be retried. This is not external exactly-once execution.

For 0.2 replayable calls, dependent decisions and effect resolution, see
[CALLS.md](CALLS.md). The exported `tests/sdk/contracts/consumer.test.mjs` composes
these mechanisms without Matt or RAC imports. The repository's older Matt M5
example is not included in the snapshot and does not exercise the new contract.
The consumer's ports are synthetic; no RAC or real host/user acceptance is claimed.

## Validation and upgrades

- `node scripts/project.mjs test`: existing product regression plus SDK contracts.
- `node scripts/project.mjs verify`: all three candidate packages, independently compared with source bytes.
- `node scripts/sdk-audit.mjs --write <manifest.json>`: freeze source membership and bytes, including untracked files.
- `node scripts/sdk-audit.mjs --baseline <manifest.json> upstream|host|local`: changes to kernel/contract fixtures require explicit SDK evolution; routine host changes are limited to adapters.

Run contract tests unchanged when comparing future candidates. Upstream acceptance must preserve SDK and contract bytes. A new event format is an SDK evolution, not a routine content update. The old native.17 runtime cannot read v2 journals: rollback requires an isolated old state snapshot, not opening new v2 state with the old runtime. Never run old and new writers on the same scope. No global installation or state migration is performed by this source change.

C tests establish component behavior; native host H and real user U require separate observations. The current Claude authentication/Q18 limitations remain open.

## 如何复用（SDK-02）

版本唯一来源是 `sdk/version.json`，与 Matt 插件版本独立。运行时仍由消费者提供；
本轮导出、契约和校验工具实测 Node **25.4.0**。依赖检查使用 Node 的 V8 模块解析及
`registerHooks`（运行命令已带所需 VM modules 参数）；未声明其他 Node 版本通过。

1. 在 Matt 上游确认 SDK、通用契约测试和导出工具已提交，然后运行：
   `node scripts/sdk-export.mjs /absolute/path/to/new-snapshot`。
   输出目录必须不存在；未提交、暂存但未提交、未跟踪或忽略的新文件都会阻止导出。
2. 把整个快照复制到消费者的固定 `vendor/task-state-sdk/` 目录。记录
   `SDK-MANIFEST.json` 的 `sdkVersion`、`sourceCommit` 和导出命令输出的清单 SHA-256。
   先用 `shasum -a 256 vendor/task-state-sdk/SDK-MANIFEST.json` 对照已记录的 hash，
   再运行 `node vendor/task-state-sdk/scripts/sdk-verify.mjs`。
3. 运行 `node vendor/task-state-sdk/scripts/sdk-contracts.mjs`。它先用 V8 解析静态
   import/re-export 图，再用 Node resolver 在测试中约束动态 import；SDK 及通用测试
   只能依赖 `sdk/` 和 `node:`，kernel 不能反向依赖可选模块。
   消费者直接 import vendor 下的 `.mjs`，构建时把快照打进自己的包。
4. 升级时完整替换为新版本快照，核对清单 hash、运行校验及契约测试，再跑消费者自己的
   集成测试。快照可搬移，不需要 Matt 仓库、Git、npm 或跨仓库运行时 import。

**vendor 目录只读。** 要改 SDK，回 Matt 走 `04-project-boundaries.md §2.1`
的 SDK 演进流程，升 SDK 版本并更新 CHANGELOG，再换快照；不要在消费者维护分叉。
Matt 自己直接使用仓库的 `sdk/`，不 vendor 自己。

`tests/sdk/contracts/` 是导出的通用契约；Matt 的旧格式、M5、运行时交互和分层审计
用例留在 `tests/sdk/matt/`，宿主适配夹具留在 `tests/sdk/adapters/`，均不随快照导出。
校验器检查缺失、多余、变更及符号链接；清单 hash 是外部钉住的信任起点，清单不自引用。
0.2.0 补齐 F2/F3，接口见 `CALLS.md`。新记录最低读取版本是 0.2.0；
resource 的新 kind 会让 0.1.0 拒绝读取，session 没有这道屏障。
不支持带新状态降级，回退必须换成隔离的旧状态目录。消费者组合验证是合成 C 证据，
不代表 RAC 或真实 H/U。此版本的验证运行时为 Node 25.4.0，未宣称其他版本已通过。
