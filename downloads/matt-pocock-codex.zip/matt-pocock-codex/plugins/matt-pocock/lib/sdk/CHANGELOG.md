# SDK changelog

The authoritative SDK version is `version.json`; Matt plugin releases use their own version.

## 0.2.1 — 2026-09-28

SDK-03 R1 implements 03 v1.2.1 V7. Declaring a dependent action now requires a
`dependentReceipt` lookup/verification port at kernel registration. Dependent
requests require their own receipt, keyed by action and originKey; absent or
mismatched receipts return `decision_required` without writing call records.
Completed requests still reuse their result before receipt lookup and guards.
Consumers must wire this port even if a particular kernel only uses completion
checks; the port may return undefined for requests without a matching receipt.

The disk format is unchanged; the reader/writer minimum for v1.2 records remains
**0.2.0**. This version changes registration and submission contracts, not stored
records. The existing downgrade restrictions still apply. Documentation now
describes supported resolution and the shared stateRoot prerequisite for
call/command exclusion.

## 0.2.0 — 2026-09-27

SDK-03 implements the approved 03 v1.2 contract. Replayable calls persist a session
anchor before prepared arguments, separate invocation from result recording, and
recover dead owners with fenced adoption outside short locks. Identity includes
the original session. Calls and effects share resource exclusion. Persisted call
scopes remain authoritative, with `scope_changed` on target drift before preparing.
Decision policies can require a completed dependent action and `sameResource`.
Unknown effects can be resolved by verified human channels or fresh successful
system reconciliation; model authority cannot resolve them.

Disk additions: resource journals add **`call` and `resolution` kinds**. Session
journals add **`command` + `callPhase`** records, including anchors and session-local
calls. These records never move generation. New receipt fields are written only
for a declared dependent action. Reader/writer minimum for the new records is
**0.2.0**. Opt-out consumers retain their existing event bytes.

**Downgrading with new state is unsupported.** A 0.1.0 reader rejects the new resource
kinds, while session journals have no downgrade barrier. Rollback must use an
isolated old state snapshot and a different state directory, never the new
journals. Do not run old and new writers against the same scope.

The portable suite uses a synthetic consumer and temporary data. This release
does not implement RAC M5, modify the old Matt example, install a plugin or prove
real host/user acceptance. Claude independent acceptance remains a separate gate
before RAC T4 consumes this snapshot. Public composition ports: [CALLS.md](CALLS.md).

## 0.1.0 — 2026-09-27

Initial SDK-01 reference contract, independently accepted by Claude R2: generic
kernel/store and action policies; durable decisions/receipts; resource-scoped
effects with success reuse and conservative crash recovery; optional delivery,
restore, lifecycle and host adapters. Includes R4 F1/F1b/F4/F5/F6 and F2 interim.
SDK-02 adds a pinned source snapshot, portable contract suite and integrity tools.

Known gaps: F2 dependency actions do not yet have the planned two-phase software
call contract; the Matt M5 example still bypasses the pipeline for confirmation
and uses handwritten recovery. F3 unknown effects block the entire resource and
have no supported resolution API. The source implementation does not implement
the later 03 v1.2 proposal. This 0.x snapshot must not be treated as T4-ready or
as real-host/user acceptance. No journal format or runtime contract changes are
introduced by SDK-02.
