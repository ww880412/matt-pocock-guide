# Replayable calls and resolution: 0.4 candidate composition ports

All constructor ports are trusted plugin/adapter code. Never forward model claims
as channel proof, authority, session binding or a prepared-call capability.

The kernel's `openStore({stateRoot})` and `openEffect({stateRoot})` must use the
same stateRoot. Different roots have separate journals and locks: calls and
commands will not exclude each other even for the same resource name.

## Prepare, invoke, record

Declare `ActionPolicy.call: 'replayable'`; it cannot also declare `externalEffect`.
The request needs an originKey. `createKernel` accepts synchronous `callArgs(ctx)`
(default: request.args); the policy may declare `callResource(ctx)` and
`callGuard(records, ctx)`. The second argument is a deeply frozen structured clone
of `{owner, request, snapshot, authority, receipt, dependentReceipt}`; it contains
no store or policy functions. When a callGuard is declared, all six context fields
(including request, snapshot and receipts) must be structured-cloneable; a function
in the request, for example, makes submission fail before the guard runs. Existing
one-argument guards remain supported under this same precondition.
Shared data requires a shared resource and consumer tests
showing safe replay and exclusion against other actions using that resource.

`submit(owner, request)` returns `PreparedCall` only after anchor and prepared fsync.
Invoke software outside locks with its frozen `args`, then call
`recordCall(prepared, {type:'Ok', result})` or `{type:'Failed', code}`. A retry of a
completed request returns the original outcome before policy/guard evaluation.
Identity contains the original `session:<host>/<id>`, local key and action.

`completeCall(prepared, invoke)` performs the invoke/record sequence. Before invoking,
it checks the durable call reference, current fence and process owner under a short
lock, then passes journal-derived arguments to `invoke` outside locks. Mutating the
caller's PreparedCall arguments does not retarget the call. Missing/mismatched refs
return `Failed(call_ref_mismatch)`, a lost fence/owner returns `Failed(owner_lost)`,
and concurrent completion through the same SDK module instance returns
`Rejected(in_flight)`. Load only one SDK vendor copy per process for this guarantee:
separate copies in one process do not share the in-flight registry, so completing
the same call through both copies can invoke it twice.
Completed calls reuse their outcome without invoking. Thrown errors become
`Failed(error.code ?? 'call_failed')`. This remains a replayable-call protocol,
not exactly-once external effects; process-death recovery can replay the software.
Never expose raw PreparedCall objects or these methods as model-facing tools.

`recoverCall(callRef, invoke)` claims only a provably dead owner and calls
`invoke(prepared)` outside locks. Return the software result or throw an error with
`code` (default `call_failed`). Dispatch by `prepared.action`; use its original args,
not current configuration. `submitAsync(owner, request, {invoke})` performs pending
recoveries and retries submit. It does **not** invoke a newly returned PreparedCall.
Other sessions can recover resource calls using a callRef returned with
`call_recovery_required`. Unknown liveness stays in flight. Liveness is local-machine
only, as with the store's lock protocol.

## Dependent decisions

Pass a static decision registry as `decisionPolicies: {kind: policy}` to createKernel.
`recordReceipt(store, sessionId, record, {policy, callResource})` runs under the session
lock. For a declared dependency it persists dependentAction, actionKey and, when
resource-bound, callScope. Its callResource callback receives `{binding, record,
owner}` and returns the same canonical name as the action's callback. Existing
receipts are reused, never rebuilt using new configuration.

The synchronous `dependentReceipt(ctx)` constructor port is required when any
decision policy declares `dependentAction`; a missing or non-function port throws
TypeError at kernel registration. It must look up the adapter-verified receipt in
the current session journal by `ctx.request.action` and `ctx.request.originKey`,
matching the receipt's `dependentAction` and `actionKey`, and return `{event, ref,
currentBinding}`. Do not select the latest receipt of that decision kind: another
ticket may be newer. Return undefined when no matching receipt exists. The kernel
checks both keys and rejects a declared dependent action with `decision_required`
when absent or mismatched, without writing an anchor or call record. Use a distinct
action name if the same software operation must also run without a decision.
Completed calls are still reused before this lookup. The kernel compares source
session, action/key, original authority, proof reference and current binding.
Only this receipt's submitting ticket is excluded from pending-decision blocking.
Do not populate this port from model-supplied receipt or authority claims.

`recoverSubmission(..., {policy, callResource, status, submit})` is synchronous.
Use `status: receipt => kernel.decisionStatus(owner, receipt)` and a submit port
that calls `kernel.submitDependent(owner, {action, originKey, args})`.
Only statically declared dependent actions are accepted (`invalid_policy` otherwise).
The kernel obtains authority from a matching journal-backed receipt, checking the
returned event/ref/digest before deriving its original channel. Request authority
and proof claims are ignored. No receipt returns `decision_required` without writes;
current binding, pending, action authority, resource and call guards still apply.
Completed actions reuse their outcome before receipt lookup, as ordinary submit does.
The lookup port must not require ctx.authority: that value is derived after lookup. PreparedCall,
call_recovery_required and an in-flight call keep the ledger submitting. Release
the lock, perform/recover the call, then recoverSubmission again to settle the
ledger. Terminal call failures become failed. A guard rejection before preparation
records answered with a rejected action. Calls remain recoverable after ledger
invalidation, replacement or eviction; recovery never resurrects the old ledger.

`requiresDecision.sameResource` requires a resource-bound dependency at registration.
For effects it compares the receipt with the **actual prepared command.resource**.
Resource names are plugin-canonicalized strings, compared by bytes. Freeze all
software inputs, including CLI data roots and paths. A pending call cannot silently
start using new configuration. The SDK does not canonicalize filesystem aliases.

`verifyDecisionRef(owner, request, ref)` is a synchronous predicate for the effect
verification port. It checks session/project binding, latest ref, decision binding,
acceptance, dependent completion and (when declared) sameResource against the current
prepared target. A missing/stale reference or check error returns false. It shares
the submit decision check, but does not replace submit or authorize an action.
Constructor lookup/target ports must remain synchronous and free of external effects.
A typical effect call uses `verify: ref => kernel.verifyDecisionRef(owner, request, ref)`.
Other artifact inputBindings still require their own verifier; this predicate only
recognizes the action's decision reference.

## Resolving an unknown effect

`openEffect({authorizeResolution})` defaults to denying resolution. This synchronous,
trusted adapter port receives `(request, context)` and returns the checked channel; request.authority cannot override
it. Call human resolution from a session action's checked kernel port, after its
ActionPolicy authorizes user-direct/user-answer. The portable consumer test shows
that path, passing `{authority: ctx.authority}` from the checked kernel event port
into resolve's separate context. Context is supplied by trusted consumer code; it
is not independently authenticated by the effect module. Never copy tool arguments
into that slot. Omitting context keeps existing adapters compatible, and the default
port still denies resolution. `effect.resolve({resource, identity, attempt, resolution, evidence}, context)` is
synchronous for human channels and appends under the resource lock; it does not
perform external lookup while locked. Evidence is a nonempty explanation or array
of artifact references. Matching repeated conclusions reuse the recorded result;
conflicts are rejected. A failed resolution permits the next command attempt.

System resolution is asynchronous: resolution must be succeeded, and a trusted
`reconcile(command)` must actually return `{status:'succeeded', evidence:[ArtifactRef,
...]}`. Start this outside session locks. Caller-supplied evidence is ignored on
this path. The resource is rechecked after reconciliation; late evidence cannot
overwrite a new attempt or conflicting resolution. Cleanup correctness remains
the human/software responsibility. Never expose these raw ports as model tools.

The `callCheckpoint`, `callInspector` and `callOwner` constructor options support
isolated fault/liveness tests; production defaults use the real process identity.
Checkpoints run after anchor fsync, prepared fsync, recovery invocation and terminal
fsync. The first invocation belongs to the consumer, so its post-invocation crash
checkpoint belongs there too. No global or environment-based fault switches exist.
