# NOTICE

The files in this directory (except this NOTICE.md) are copied **unmodified** from the upstream Pi extension package
`pi-matt-pocock@0.1.0`:

- Source repository: https://github.com/FradSer/pi-packages
- Package path: `packages/matt-pocock/procedures/` (54 files) and `packages/matt-pocock/LICENSE`
- Upstream commit: `eda991d4d793158f3f59d996b8ba049e9fb64d02`
- License: MIT (see `LICENSE` in this directory; copyright Matt Pocock, Jesse Vincent, Frad LEE)
- Upstream provenance of the procedures themselves: `mattpocock/skills` (see the upstream package's UPSTREAM.md)

File names are kept exactly as upstream (`procedures/<name>` → `resources/<name>`), contents are byte-identical, and every
file is pinned by SHA-256 in `core/manifest.json` (generated from `evidence/baseline.json`; `scripts/manifest.mjs --check`
verifies this directory against it). Only the 15 procedures reachable through the route tables are loaded as workflow
procedures; the remaining files are supporting material referenced by them.

Modifications: none.

| File | SHA-256 |
|---|---|
| ADR-FORMAT.md | f1f36cd3f8d3b6474ddd5855da4e233bfc4ae1a1c5024909ccf11871819a41b2 |
| AGENT-BRIEF.md | da191e5c5bc2486c5bd666645456452e77449e4d4681e3e5b4b005a010bacba9 |
| bdd-best-practices.md | 1d0ba44af4c54f31db13c68bed975901cb5a52efc9fecfcb94b4b2353eb30f41 |
| bdd.md | 849d9ff0b358e86ef0e1d597c0829d39ba28171e617dbf03a4e0f9719aff7498 |
| code-review.md | 6e9d430175e688dcc753106652e53d4250b729fbd653c58cafc349be7628d2e4 |
| codebase-design.md | cf05c27120a2ebf3aced2e6f9eede7f04e315746e8ae0ae9d02a26847d2271fa |
| CONTEXT-FORMAT.md | b8cc318f2a4285b530e908b6bc43901c3c5cd11100362636bbc4216639bef597 |
| DEEPENING.md | 8e310be92b1f63c52c8797de03cf7e05ff09cfb5b11a06840b72bada6ea2e79d |
| DESIGN-IT-TWICE.md | 39d97050b64a1e2c8509e4d610124f8da9dd4fb057568b2f668b3f89262bf7c5 |
| diagnosing-bugs.md | 71c759c634f17902f31cf8a89c3ab3dbe343c509882fc24864f5136955323c81 |
| domain-modeling.md | a0bfd49fa535a4c5b96ba56eb5828ad01590a8526dd7382032dce7435eaa8635 |
| domain.md | d9f215e0348ad3cbf9e7332722a41d3eeb002d4d9b595761c650c62c81db3741 |
| gherkin-guide.md | 042dfc487368e1a7a9976e0f75f1eb27bace504a32952eb145d53f93f9c4fea5 |
| GLOSSARY-FORMAT.md | d177def491519d97873291f2e860d8f1d60ead78feecb82eee022177958069c6 |
| GLOSSARY.md | 3f280636e3b62b54e86fbb153c90f48293414a0e16f1de64fdec270509963362 |
| grill-me.md | 32053ec24b2f8df0665fa6f006a95b31a0ee2e129361d093374abd437fd70ae7 |
| grill-with-docs.md | 4e0afa1fbe1323880199637e8ad1c8dff0042ddc986e5a8cd77cfcbeadbc5c52 |
| grilling.md | 3a9e069ba2f99b9260292b3e369aec86f6f137a14f9ae26fb7c1db7d43d9400d |
| handoff.md | 57029688c6d35591ca6d1ccf34464c02bb53408601529eb88fd8df3ea011f03a |
| hitl-loop.template.sh | 18ae07e1cc49b32c71767e241a6e8de4be74ef21d5e3b7e39034d9c7335f2d80 |
| HTML-REPORT.md | e749a45cdd4e834d6865f4d4bb8d16497037b074374c60bbd0e4e6bc68aaa865 |
| implement.md | 03c665011be5c9f353d54c9fcc13a90b3268e0f9ed44c412e66617deebf24f40 |
| improve-codebase-architecture.md | 90cd9c09cc92aca634fea5ab33b3997ac4ba008588823054160633bcec2e6eca |
| issue-tracker-github.md | 1b805c24c77f1cc475c63a5e56f9058036753054584f4c705331205cc5e2b477 |
| issue-tracker-gitlab.md | 54393a4670920ed64b13ba2df63b7a90201c76e13e56355559a1d4c5cd0fef30 |
| issue-tracker-local.md | 2444adcf16af6ea1b2f5226ed8ed84a2845aad06a48d5aedd2f7b92ef3d392ac |
| LEARNING-RECORD-FORMAT.md | 855f81017625256584bbf62bd5edb9b0c86605c4cc1139c56acc36b802595d17 |
| LOGIC.md | 7199d02a5f8ad47f0c98b2b5336fef6bc504104da39786aa64440bdffa51ed1c |
| MISSION-FORMAT.md | 8da6d3ac84eb2eb19f17c260b6acf01c560d3ac7a4501c415eea0e985602f4d7 |
| mocking.md | 3ceb807fdf4a47d6a93d4d9a891e5ba6d362a6247bd08adc451feebfc17361ef |
| OUT-OF-SCOPE.md | 2526f998fd7ca5e956d3f6f234bcc2431a5971ee769f1148ddc60b92f04d5914 |
| phase-boundaries.md | ac4fa6a8bc28bd6ab16efeadc2063589dc037b4db4d8c06c73f7e692fac069ad |
| prototype.md | 4f079447388115a417e052a31287446503c2bc09fa3e80f34375707e670e5d7a |
| research.md | d9574c51347f7f25be02348f8f0f6d2efd4a3cd4a84c99b670384952657c444e |
| resolving-merge-conflicts.md | 05098a9cc3b5ca67cd1f4e4896e215719f6d39d8748d7d2105d5a4beeb4b3331 |
| RESOURCES-FORMAT.md | 6f772fdcea08e72a5405239bbad60a8094ac026525ed455077ee0a1898be6ce9 |
| setup-matt-pocock-skills.md | 8322aa697a257fb57a5e7a18773fcf0a52a8a8aab0c9fd1cc3ce31348b503035 |
| SKILL-MECHANICS.md | 0d8c3cfa3df59c1f0673cf123d0c1a71781efcbc9e8b59df386ae47c50aa60d5 |
| tdd.md | f9acf005877a7822b3c0d8d51e5128437b230fd6e86f5b797c7d27e908cb41e9 |
| teach.md | 6831c15574eead43806dc4bf336c74d0ae4a59e91a29d04223a8d3d9c7f18f95 |
| template.sh | d43dc3f7b6008779ef55e3935bf1df246b5bc194b7f9e1dee3d9340a00922ce6 |
| testing-anti-patterns.md | 4fcaa4931ffbf17622304b54614c245dead7e523b24069754fcd95ce810da1fa |
| tests.md | 859f9e592c188fda4fc7277dd180e4ce9c7a2e13f6efe1f6f29eccc9d28c106a |
| to-questionnaire.md | 85ef07ac995cbf3c32e0db3f7ca8ec926adff2956209565461cd307f4dd47498 |
| to-spec.md | 99ba54180f567475bcf949f54bc3ae1613dafa373e4ef0fe5dfb0c623a40afba |
| to-tickets.md | fdc863deb0132a608d8c95fa60701187fd2523f1804b97806e7ea7cb9dc9efd6 |
| triage-labels.md | 4f53c9b40ce2651e3611aa090eaedbd6dbc9b71ef8c5f7e65eac0d8263190d0d |
| triage.md | f94e5de483f761b21ae3887e936bf76f9cbd2d2d2e1c84bbd237543ea66858ff |
| UI.md | 35c60cd1396e4fcdda85978b87197f944cfa5db29172df9d8305264f74c6f65b |
| wait-what.md | 789e8a4080c53e01cfd0ac18aed36443b5d715fa9b4c31915a9954c6782acc06 |
| wayfinder.md | a155d6e17da0d319125b21ffa93ddbc76d8e4da98c3f0196ea5e5992fd6107ef |
| wizard.md | b9ff88dff19317bd0e924bb891dad3732dc8ed022a3bc8bb8d8e391b4df549bc |
| writing-for-agents.md | 7491cb60add9a701e6a4581d807493d0e9bf1ff0871f0df20285349ca32315ba |
| writing-great-skills.md | bdc74b4ccc62cbad480dc220ad41982eddaedbe993a2fbf45d706041885d9092 |
