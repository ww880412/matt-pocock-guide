# BDD-Driven TDD (Automation)

BDD cycles through three phases: **Discovery** (conversations → examples), **Formulation** (Gherkin scenarios), **Automation** (red-green-refactor, driven by BDD). This skill is the **BDD-driven Automation** reference — the how of test implementation, once [bdd](bdd.md) has defined the what.

When invoked during [implement](implement.md) or [bdd](bdd.md), use this skill as the test-writing authority. The [bdd](bdd.md) skill governs the scenario design and Iron Law; this skill governs the test code quality under BDD discipline.

## CRITICAL: BDD scenarios come first

If you reached this skill directly (not via [bdd](bdd.md) or [implement](implement.md)), inspect the repository and conversation for Gherkin scenarios first.

- If scenarios are absent → invoke [bdd](bdd.md) to define them, then return here for Automation.
- If scenarios exist in `.feature` files or equivalent → proceed with the red-green loop below.
- Ask the user only if the behavior itself is genuinely unresolved; do not ask for confirmation of facts that repository exploration can establish.

## What a good test is

Tests verify behavior through public interfaces, not implementation details. Code can change entirely; tests shouldn't. A good test reads like a specification — "user can checkout with valid cart" tells you exactly what capability exists — and survives refactors because it doesn't care about internal structure.

See [tests.md](tests.md) for examples and [mocking.md](mocking.md) for mocking guidelines.

## Seams — where tests go

A **seam** is the public boundary you test at: the interface where you observe behavior without reaching inside. Tests live at seams, never against internals.

**Test at the highest established seam.** Record the public boundary under test and select the highest existing seam that expresses the confirmed behavior. Not everything can be tested — choosing the critical public seam deliberately is how effort lands on complex behavior instead of every edge case. Ask only when the public contract is genuinely ambiguous.

When the shape of that interface is itself in question — how deep the module is, where the seam belongs, what the interface should expose — use the [codebase-design](codebase-design.md) skill for the vocabulary. It is the shared source of the module, interface, depth, seam, adapter, leverage and locality terms, and it is a reference to consult, not a session to run.

## Anti-patterns

- **Implementation-coupled** — mocks internal collaborators, tests private methods, or verifies through a side channel (querying the database instead of using the interface). The tell: the test breaks when you refactor but behavior hasn't changed.
- **Tautological** — the assertion recomputes the expected value the way the code does (`expect(add(a, b)).toBe(a + b)`, a snapshot derived by hand the same way, a constant asserted equal to itself), so it passes by construction and can never disagree with the code. Expected values must come from an independent source of truth — a known-good literal, a worked example, the spec.
- **Horizontal slicing** — writing all tests first, then all implementation. Bulk tests verify _imagined_ behavior: you test the _shape_ of things rather than user-facing behavior, the tests go insensitive to real changes, and you commit to test structure before understanding the implementation. Work in **vertical slices** instead — one test → one implementation → repeat, each test a **tracer bullet** that responds to what the last cycle taught you.

## Rules of the loop

- **Red before green.** Write the failing test first, then only enough code to pass it. Don't anticipate future tests or add speculative features.
- **One slice at a time.** One seam, one test, one minimal implementation per cycle.
- **Refactoring is not part of the loop.** It belongs to the review stage (see [code-review](code-review.md)), not the red → green implementation cycle.

## CRITICAL: BDD-Driven — not standalone TDD

This skill is the **Automation** phase of the BDD lifecycle. It always runs under [bdd](bdd.md) or [implement](implement.md) as **BDD-driven TDD**. If invoked directly, see the CRITICAL check at the top of this file — confirm scenarios exist before writing test code.

1. **Discovery** (what behavior matters) — owned by [bdd](bdd.md) via Gherkin scenarios
2. **Formulation** (scenario as specification) — owned by [bdd](bdd.md) via `.feature` files
3. **Automation** (this skill) — the red-green loop that makes the scenario pass

## When to invoke

Invoke this skill explicitly when:
- The user asks "how should I test this?" during BDD implementation
- The user asks about mocking, seams, or test structure
- The user writes a test that looks implementation-coupled
- The user asks about mocking strategy at system boundaries
- The user is unsure whether a test is good or tautological

When invoked directly, first check if Gherkin scenarios exist (see the CRITICAL check at the top). If not, redirect to [bdd](bdd.md) before proceeding with Automation.

The [bdd](bdd.md) and [implement](implement.md) skills load this automatically during the Automation phase — you do not need to invoke it separately in those flows.